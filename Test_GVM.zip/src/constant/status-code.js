module.exports.statusCode = {
    OK: 200,
    BAD_REQUEST: 400,
    INTERNAL_ERROR: 500,
};