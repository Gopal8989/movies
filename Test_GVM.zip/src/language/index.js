const en = require('./en.js');

module.exports = {
    en,
};
