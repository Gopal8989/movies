const validateMiddleware = require('./validate.js');
module.exports = {
    validateMiddleware,
};
